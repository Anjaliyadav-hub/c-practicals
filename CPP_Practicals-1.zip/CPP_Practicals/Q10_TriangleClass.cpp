/*
 * Program: Q10_TriangleClass.cpp
 * Purpose: Create a Triangle class with:
 *          - Exception handling for valid triangle conditions:
 *            * All sides > 0
 *            * Sum of any two sides > third side
 *          - Overloaded function area() for:
 *            * Right-angled triangle: area = (1/2) * base * height
 *            * Any triangle using Heron's formula
 *
 * Heron's Formula:
 *   s = (a + b + c) / 2      (semi-perimeter)
 *   area = sqrt(s*(s-a)*(s-b)*(s-c))
 *
 * Compile: g++ Q10_TriangleClass.cpp -o Q10_TriangleClass
 * Run:     ./Q10_TriangleClass
 */

#include <iostream>
#include <cmath>       // for sqrt()
#include <stdexcept>   // for invalid_argument
#include <string>
using namespace std;

// ---- Triangle Class ----
class Triangle {
private:
    double a, b, c;   // Sides of the triangle

    // Validate triangle sides — throws exceptions if invalid
    void validate() {
        // Check: all sides must be > 0
        if (a <= 0 || b <= 0 || c <= 0) {
            throw invalid_argument("All sides must be greater than 0.");
        }
        // Check: sum of any two sides must be greater than the third side
        if ((a + b <= c) || (a + c <= b) || (b + c <= a)) {
            throw invalid_argument(
                "Invalid triangle: Sum of any two sides must be greater than the third side."
            );
        }
    }

public:
    // Constructor — validates immediately upon creation
    Triangle(double sideA, double sideB, double sideC)
        : a(sideA), b(sideB), c(sideC) {
        validate();   // Throws exception if invalid
    }

    // ---- Overloaded area() for RIGHT-ANGLED triangle ----
    // Uses: area = 0.5 * base * height
    // (Only two parameters needed)
    double area(double base, double height) {
        if (base <= 0 || height <= 0) {
            throw invalid_argument("Base and height must be greater than 0.");
        }
        return 0.5 * base * height;
    }

    // ---- Overloaded area() using HERON'S FORMULA ----
    // (No parameters — uses object's own sides a, b, c)
    double area() {
        double s = (a + b + c) / 2.0;   // Semi-perimeter
        return sqrt(s * (s - a) * (s - b) * (s - c));
    }

    // Display triangle information
    void display() {
        cout << "Triangle sides: a=" << a << ", b=" << b << ", c=" << c << endl;
        cout << "Perimeter: " << (a + b + c) << endl;
    }
};

int main() {
    cout << "===== Triangle Class Demo =====" << endl;

    // ---- Test 1: Valid Triangle ----
    try {
        cout << "\n[Test 1] Creating triangle with sides 3, 4, 5 (valid right triangle):" << endl;
        Triangle t1(3, 4, 5);
        t1.display();

        // Area using Heron's formula (all three sides)
        cout << "Area (Heron's formula): " << t1.area() << endl;

        // Area as right-angled triangle (base=3, height=4)
        cout << "Area (right-angle, base=3, height=4): " << t1.area(3, 4) << endl;

    } catch (invalid_argument& e) {
        cout << "[EXCEPTION] " << e.what() << endl;
    }

    // ---- Test 2: All sides must be > 0 ----
    try {
        cout << "\n[Test 2] Creating triangle with sides -1, 4, 5 (invalid - negative side):" << endl;
        Triangle t2(-1, 4, 5);   // Should throw exception
        t2.display();
    } catch (invalid_argument& e) {
        cout << "[EXCEPTION CAUGHT] " << e.what() << endl;
    }

    // ---- Test 3: Triangle inequality violation ----
    try {
        cout << "\n[Test 3] Creating triangle with sides 1, 2, 10 (invalid - inequality violated):" << endl;
        Triangle t3(1, 2, 10);   // 1+2 = 3, which is NOT > 10
        t3.display();
    } catch (invalid_argument& e) {
        cout << "[EXCEPTION CAUGHT] " << e.what() << endl;
    }

    // ---- Test 4: General triangle (not right-angled) ----
    try {
        cout << "\n[Test 4] Creating triangle with sides 6, 8, 10:" << endl;
        Triangle t4(6, 8, 10);
        t4.display();
        cout << "Area (Heron's formula): " << t4.area() << endl;
        cout << "Area (right-angle, base=6, height=8): " << t4.area(6, 8) << endl;
    } catch (invalid_argument& e) {
        cout << "[EXCEPTION CAUGHT] " << e.what() << endl;
    }

    // ---- Interactive Mode ----
    cout << "\n===== Enter Your Own Triangle =====" << endl;
    double a, b, c;
    cout << "Enter sides a, b, c: ";
    cin >> a >> b >> c;

    try {
        Triangle t(a, b, c);
        t.display();
        cout << "Area using Heron's formula: " << t.area() << endl;

        cout << "Is it a right-angled triangle? Enter base and height (or 0 0 to skip): ";
        double base, height;
        cin >> base >> height;
        if (base > 0 && height > 0) {
            cout << "Area (right-angle): " << t.area(base, height) << endl;
        }
    } catch (invalid_argument& e) {
        cout << "[EXCEPTION CAUGHT] " << e.what() << endl;
    }

    return 0;
}

/*
 * Sample Output:
 * -------------------
 * [Test 1] Creating triangle with sides 3, 4, 5:
 * Triangle sides: a=3, b=4, c=5
 * Perimeter: 12
 * Area (Heron's formula): 6
 * Area (right-angle, base=3, height=4): 6
 *
 * [Test 2] EXCEPTION CAUGHT: All sides must be greater than 0.
 * [Test 3] EXCEPTION CAUGHT: Sum of any two sides must be greater than the third.
 */
