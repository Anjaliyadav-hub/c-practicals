/*
 * Program: Q12_CopyFileWithoutSpaces.cpp
 * Purpose: Copy the contents of one text file to another,
 *          but remove ALL whitespace characters (spaces, tabs, newlines).
 *
 * File Operations Used:
 *   - ifstream: Read from source file character by character
 *   - ofstream: Write to destination file
 *   - isspace(): Standard function to check if a character is whitespace
 *
 * Compile: g++ Q12_CopyFileWithoutSpaces.cpp -o Q12_CopyFileWithoutSpaces
 * Run:     ./Q12_CopyFileWithoutSpaces source.txt destination.txt
 *
 * Note: A sample source file "source.txt" is auto-created if not found.
 */

#include <iostream>
#include <fstream>   // for file I/O
#include <cctype>    // for isspace()
#include <string>
using namespace std;

// Function to create a sample source file for testing
void createSampleFile(const string& filename) {
    ofstream f(filename);
    if (!f) {
        cout << "Could not create sample file." << endl;
        return;
    }
    f << "Hello World!\n";
    f << "This is    a test   file.\n";
    f << "It has lots of    whitespace   and\ttabs.\n";
    f << "Line 4: extra   spaces   here.\n";
    f.close();
    cout << "[INFO] Sample source file created: " << filename << endl;
}

int main(int argc, char* argv[]) {
    string sourceFile, destFile;

    // Get file names from command-line or prompt user
    if (argc >= 3) {
        sourceFile = argv[1];
        destFile   = argv[2];
    } else {
        cout << "Enter source file name: ";
        cin >> sourceFile;
        cout << "Enter destination file name: ";
        cin >> destFile;
    }

    // Try opening source file; create a sample if it doesn't exist
    ifstream inFile(sourceFile);
    if (!inFile) {
        cout << "[WARNING] Source file '" << sourceFile << "' not found." << endl;
        createSampleFile(sourceFile);
        inFile.open(sourceFile);   // Try opening again
        if (!inFile) {
            cout << "[ERROR] Cannot open source file." << endl;
            return 1;
        }
    }

    // Open destination file for writing
    ofstream outFile(destFile);
    if (!outFile) {
        cout << "[ERROR] Cannot open destination file '" << destFile << "' for writing." << endl;
        return 1;
    }

    cout << "\n[INFO] Copying from '" << sourceFile << "' to '" << destFile
         << "' (removing all whitespace)..." << endl;

    int totalChars   = 0;
    int removedChars = 0;
    char ch;

    // Read one character at a time
    while (inFile.get(ch)) {
        totalChars++;

        if (isspace(ch)) {
            // Skip all whitespace characters (space, tab, \n, \r, etc.)
            removedChars++;
        } else {
            // Write non-whitespace characters to destination
            outFile.put(ch);
        }
    }

    inFile.close();
    outFile.close();

    // Summary
    cout << "[INFO] Done!" << endl;
    cout << "  Total characters read   : " << totalChars           << endl;
    cout << "  Whitespace removed      : " << removedChars         << endl;
    cout << "  Characters written      : " << (totalChars - removedChars) << endl;

    // Display contents of both files
    cout << "\n--- Contents of SOURCE file (" << sourceFile << ") ---" << endl;
    ifstream showSrc(sourceFile);
    string line;
    while (getline(showSrc, line)) cout << line << endl;
    showSrc.close();

    cout << "\n--- Contents of DESTINATION file (" << destFile << ") ---" << endl;
    ifstream showDest(destFile);
    while (getline(showDest, line)) cout << line << endl;
    showDest.close();

    return 0;
}

/*
 * Sample Input/Output:
 * -------------------
 * ./Q12_CopyFileWithoutSpaces source.txt output.txt
 *
 * [INFO] Sample source file created: source.txt
 * [INFO] Copying from 'source.txt' to 'output.txt' (removing all whitespace)...
 * [INFO] Done!
 *   Total characters read   : 84
 *   Whitespace removed      : 30
 *   Characters written      : 54
 *
 * --- Contents of SOURCE file ---
 * Hello World!
 * This is    a test   file.
 *
 * --- Contents of DESTINATION file ---
 * HelloWorld!Thisisatestfile.Ithastaksofswhitespaceandtabs.Line4:extraspaceshere.
 */
