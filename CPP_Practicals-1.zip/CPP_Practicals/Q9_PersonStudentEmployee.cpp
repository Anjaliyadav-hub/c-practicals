/*
 * Program: Q9_PersonStudentEmployee.cpp
 * Purpose: Demonstrate inheritance and runtime polymorphism.
 *          - Base class:    Person (name)
 *          - Derived class: Student (course, marks, year)
 *          - Derived class: Employee (department, salary)
 *          Each class has a display() method (virtual for polymorphism).
 *
 * Concepts Used:
 *   - Single inheritance (Student and Employee inherit from Person)
 *   - virtual keyword for runtime polymorphism
 *   - Base class pointer pointing to derived class objects
 *
 * Compile: g++ Q9_PersonStudentEmployee.cpp -o Q9_PersonStudentEmployee
 * Run:     ./Q9_PersonStudentEmployee
 */

#include <iostream>
#include <string>
using namespace std;

// ---- Base Class: Person ----
class Person {
protected:
    string name;   // Shared data member

public:
    // Constructor
    Person(string n) : name(n) {}

    // Virtual destructor — important when using base class pointers
    virtual ~Person() {}

    // Virtual display() — overridden in derived classes
    // 'virtual' keyword enables runtime polymorphism
    virtual void display() {
        cout << "Name: " << name << endl;
    }
};

// ---- Derived Class: Student ----
class Student : public Person {
private:
    string course;
    float  marks;
    int    year;

public:
    // Constructor calls Person's constructor for name
    Student(string n, string c, float m, int y)
        : Person(n), course(c), marks(m), year(y) {}

    // Override display() — displays all Student attributes
    void display() override {
        cout << "--- Student Details ---" << endl;
        cout << "Name   : " << name    << endl;
        cout << "Course : " << course  << endl;
        cout << "Marks  : " << marks   << endl;
        cout << "Year   : " << year    << endl;
    }
};

// ---- Derived Class: Employee ----
class Employee : public Person {
private:
    string department;
    double salary;

public:
    // Constructor
    Employee(string n, string dept, double sal)
        : Person(n), department(dept), salary(sal) {}

    // Override display() — displays all Employee attributes
    void display() override {
        cout << "--- Employee Details ---" << endl;
        cout << "Name       : " << name       << endl;
        cout << "Department : " << department << endl;
        cout << "Salary     : " << salary     << endl;
    }
};

int main() {
    // Create objects of each class
    Person   person("Alice");
    Student  student("Bob", "Computer Science", 88.5f, 2);
    Employee employee("Charlie", "Engineering", 75000.0);

    // ---- Direct object calls ----
    cout << "=== Direct Object Calls ===" << endl;
    person.display();
    cout << endl;
    student.display();
    cout << endl;
    employee.display();
    cout << endl;

    // ---- Runtime Polymorphism via Base Class Pointers ----
    // A base class pointer can hold derived class objects.
    // The correct display() is called at RUNTIME based on actual object type.
    cout << "=== Runtime Polymorphism (Base Class Pointers) ===" << endl;

    Person* ptr;   // Base class pointer

    // Point to Person object — calls Person::display()
    ptr = &person;
    ptr->display();
    cout << endl;

    // Point to Student object — calls Student::display() (runtime decision!)
    ptr = &student;
    ptr->display();
    cout << endl;

    // Point to Employee object — calls Employee::display() (runtime decision!)
    ptr = &employee;
    ptr->display();
    cout << endl;

    // ---- Array of Base Class Pointers ----
    cout << "=== Array of Pointers (Polymorphic Array) ===" << endl;
    Person* people[3];
    people[0] = new Person("Person_1");
    people[1] = new Student("Student_1", "Mathematics", 92.0f, 3);
    people[2] = new Employee("Employee_1", "HR", 55000.0);

    for (int i = 0; i < 3; i++) {
        people[i]->display();   // Calls correct function at runtime
        cout << endl;
    }

    // Clean up allocated memory
    for (int i = 0; i < 3; i++) delete people[i];

    return 0;
}

/*
 * Sample Output:
 * -------------------
 * === Direct Object Calls ===
 * Name: Alice
 *
 * --- Student Details ---
 * Name   : Bob
 * Course : Computer Science
 * Marks  : 88.5
 * Year   : 2
 *
 * --- Employee Details ---
 * Name       : Charlie
 * Department : Engineering
 * Salary     : 75000
 *
 * === Runtime Polymorphism (Base Class Pointers) ===
 * Name: Alice
 *
 * --- Student Details ---
 * Name   : Bob   ...
 *
 * --- Employee Details ---
 * Name       : Charlie  ...
 */
