/*
 * Program: Q4_StringManipulation.cpp
 * Purpose: Menu-driven program to perform string operations WITHOUT
 *          using built-in string functions.
 * Operations:
 *   a) Show address of each character
 *   b) Concatenate two strings
 *   c) Compare two strings
 *   d) Calculate length of string (using pointers)
 *   e) Convert lowercase to uppercase
 *   f) Reverse the string
 *   g) Insert a string into another at a user-specified position
 *
 * Compile: g++ Q4_StringManipulation.cpp -o Q4_StringManipulation
 * Run:     ./Q4_StringManipulation
 */

#include <iostream>
using namespace std;

// ---- Helper Functions (NO built-in string functions used) ----

// Get length of a string using pointer arithmetic
int myLength(const char* str) {
    const char* ptr = str;
    while (*ptr != '\0') ptr++;   // Move pointer until null terminator
    return ptr - str;             // Difference gives length
}

// Copy src into dest
void myCopy(char* dest, const char* src) {
    while (*src != '\0') {
        *dest = *src;
        dest++;
        src++;
    }
    *dest = '\0';   // Null-terminate the destination
}

// Concatenate src to end of dest (dest must have enough space)
void myConcat(char* dest, const char* src) {
    // Move dest pointer to its end
    while (*dest != '\0') dest++;
    // Append src
    while (*src != '\0') {
        *dest = *src;
        dest++;
        src++;
    }
    *dest = '\0';
}

// Compare two strings: returns 0 if equal, <0 if s1<s2, >0 if s1>s2
int myCompare(const char* s1, const char* s2) {
    while (*s1 != '\0' && *s2 != '\0') {
        if (*s1 != *s2) return *s1 - *s2;
        s1++;
        s2++;
    }
    return *s1 - *s2;   // Check if one string ended before the other
}

// Convert lowercase to uppercase
void toUpper(char* str) {
    while (*str != '\0') {
        if (*str >= 'a' && *str <= 'z') {
            *str = *str - 32;   // ASCII difference between 'a' and 'A' is 32
        }
        str++;
    }
}

// Reverse a string in place
void myReverse(char* str) {
    int len = myLength(str);
    char* left  = str;
    char* right = str + len - 1;
    while (left < right) {
        // Swap characters
        char temp = *left;
        *left  = *right;
        *right = temp;
        left++;
        right--;
    }
}

// Insert 'insert' string into 'original' at position 'pos'
// Result is stored in 'result' (must have enough space)
void myInsert(const char* original, const char* insert, int pos, char* result) {
    int origLen   = myLength(original);
    int insertLen = myLength(insert);

    // Clamp position to valid range
    if (pos < 0)        pos = 0;
    if (pos > origLen)  pos = origLen;

    // Copy characters before position
    for (int i = 0; i < pos; i++) result[i] = original[i];

    // Insert the new string
    for (int i = 0; i < insertLen; i++) result[pos + i] = insert[i];

    // Copy the rest of the original string
    for (int i = pos; i <= origLen; i++) result[insertLen + i] = original[i];
    // Note: original[origLen] is '\0', which also null-terminates result
}

// ---- Main Program ----

int main() {
    int choice;
    char str1[300], str2[300], result[600];

    do {
        // Display the menu
        cout << "\n===== String Manipulation Menu =====" << endl;
        cout << "a. Show address of each character" << endl;
        cout << "b. Concatenate two strings" << endl;
        cout << "c. Compare two strings" << endl;
        cout << "d. Calculate length of string (using pointers)" << endl;
        cout << "e. Convert lowercase to uppercase" << endl;
        cout << "f. Reverse the string" << endl;
        cout << "g. Insert a string into another at a position" << endl;
        cout << "0. Exit" << endl;
        cout << "Enter your choice: ";

        char ch;
        cin >> ch;
        cin.ignore();   // Clear the newline from the input buffer

        switch (ch) {
            case 'a':
            case 'A':
                cout << "Enter a string: ";
                cin.getline(str1, 300);
                cout << "\nCharacter | Address" << endl;
                cout << "----------|----------------" << endl;
                for (int i = 0; str1[i] != '\0'; i++) {
                    // &str1[i] gives the memory address of character at index i
                    cout << "    " << str1[i] << "     | " << (void*)&str1[i] << endl;
                }
                break;

            case 'b':
            case 'B':
                cout << "Enter first string: ";
                cin.getline(str1, 300);
                cout << "Enter second string: ";
                cin.getline(str2, 300);
                myConcat(str1, str2);
                cout << "Concatenated string: " << str1 << endl;
                break;

            case 'c':
            case 'C':
                cout << "Enter first string: ";
                cin.getline(str1, 300);
                cout << "Enter second string: ";
                cin.getline(str2, 300);
                {
                    int cmp = myCompare(str1, str2);
                    if (cmp == 0)
                        cout << "Strings are EQUAL." << endl;
                    else if (cmp < 0)
                        cout << "\"" << str1 << "\" is LESS THAN \"" << str2 << "\"" << endl;
                    else
                        cout << "\"" << str1 << "\" is GREATER THAN \"" << str2 << "\"" << endl;
                }
                break;

            case 'd':
            case 'D':
                cout << "Enter a string: ";
                cin.getline(str1, 300);
                cout << "Length of string (using pointers): " << myLength(str1) << endl;
                break;

            case 'e':
            case 'E':
                cout << "Enter a string: ";
                cin.getline(str1, 300);
                toUpper(str1);
                cout << "Uppercase: " << str1 << endl;
                break;

            case 'f':
            case 'F':
                cout << "Enter a string: ";
                cin.getline(str1, 300);
                myReverse(str1);
                cout << "Reversed: " << str1 << endl;
                break;

            case 'g':
            case 'G':
                cout << "Enter the original string: ";
                cin.getline(str1, 300);
                cout << "Enter the string to insert: ";
                cin.getline(str2, 300);
                {
                    int pos;
                    cout << "Enter position to insert at (0-based): ";
                    cin >> pos;
                    cin.ignore();
                    myInsert(str1, str2, pos, result);
                    cout << "Result after insertion: " << result << endl;
                }
                break;

            case '0':
                cout << "Exiting. Goodbye!" << endl;
                break;

            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    } while (true);

    // Note: loop exits via 'return' inside case '0' indirectly through program end
    // Adding explicit exit below
    return 0;
}

/*
 * Sample Input/Output:
 * -------------------
 * ===== String Manipulation Menu =====
 * Enter your choice: d
 * Enter a string: Hello
 * Length of string (using pointers): 5
 *
 * Enter your choice: f
 * Enter a string: Hello
 * Reversed: olleH
 *
 * Enter your choice: g
 * Enter the original string: HelloWorld
 * Enter the string to insert: ___
 * Enter position to insert at (0-based): 5
 * Result after insertion: Hello___World
 */
