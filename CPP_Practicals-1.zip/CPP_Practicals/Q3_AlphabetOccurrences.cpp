/*
 * Program: Q3_AlphabetOccurrences.cpp
 * Purpose: Print a table showing the number of occurrences of each
 *          alphabet in the text entered as a command-line argument.
 * Logic:
 *   - Count each letter (a-z, case-insensitive) in the input text.
 *   - Display a table of alphabet vs. count.
 * Input:  Text as command-line argument (e.g., ./Q3 "Hello World")
 * Output: Table of each alphabet and its occurrence count
 *
 * Compile: g++ Q3_AlphabetOccurrences.cpp -o Q3_AlphabetOccurrences
 * Run:     ./Q3_AlphabetOccurrences "Hello World"
 *
 * Sample Output:
 *   Alphabet | Occurrences
 *   d        | 1
 *   e        | 1
 *   h        | 1
 *   l        | 3
 *   o        | 2
 *   r        | 1
 *   w        | 1
 */

#include <iostream>
#include <cstring>    // for strlen()
#include <cctype>     // for tolower(), isalpha()
using namespace std;

int main(int argc, char* argv[]) {
    // Check if text was provided as command-line argument
    if (argc < 2) {
        cout << "Usage: " << argv[0] << " \"your text here\"" << endl;
        cout << "Example: " << argv[0] << " \"Hello World\"" << endl;
        return 1;
    }

    // Combine all command-line arguments into one string
    // (in case user typed multiple words without quotes)
    string text = "";
    for (int i = 1; i < argc; i++) {
        if (i > 1) text += " ";
        text += argv[i];
    }

    cout << "Input text: \"" << text << "\"" << endl << endl;

    // Array to count occurrences of each letter (index 0=a, 1=b, ..., 25=z)
    int count[26] = {0};   // Initialize all to 0

    // Loop through each character and count alphabets
    for (int i = 0; i < (int)text.length(); i++) {
        char ch = tolower(text[i]);   // Convert to lowercase for uniformity
        if (isalpha(ch)) {
            count[ch - 'a']++;        // Map 'a'->0, 'b'->1, ..., 'z'->25
        }
    }

    // Print the table header
    cout << "Alphabet | Occurrences" << endl;
    cout << "---------|------------" << endl;

    // Print only alphabets that appeared at least once
    for (int i = 0; i < 26; i++) {
        if (count[i] > 0) {
            char letter = 'a' + i;
            cout << "   " << letter << "     |     " << count[i] << endl;
        }
    }

    // Total characters counted
    int total = 0;
    for (int i = 0; i < 26; i++) total += count[i];
    cout << "\nTotal alphabetic characters: " << total << endl;

    return 0;
}

/*
 * Sample Input/Output:
 * -------------------
 * ./Q3_AlphabetOccurrences "Hello World"
 *
 * Input text: "Hello World"
 *
 * Alphabet | Occurrences
 * ---------|------------
 *    d     |     1
 *    e     |     1
 *    h     |     1
 *    l     |     3
 *    o     |     2
 *    r     |     1
 *    w     |     1
 *
 * Total alphabetic characters: 10
 */
