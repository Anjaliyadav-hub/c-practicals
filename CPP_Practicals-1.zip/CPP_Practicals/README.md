# C++ Practicals – Complete Programs

A collection of 12 beginner-friendly C++ programs covering arrays, strings, OOP, recursion, file handling, and exception handling.

---

## Folder Structure

```
CPP_Practicals/
├── Q1_SeriesSum.cpp
├── Q2_RemoveDuplicates.cpp
├── Q3_AlphabetOccurrences.cpp
├── Q4_StringManipulation.cpp
├── Q5_MergeOrderedArrays.cpp
├── Q6_BinarySearch.cpp
├── Q7_GCD.cpp
├── Q8_MatrixClass.cpp
├── Q9_PersonStudentEmployee.cpp
├── Q10_TriangleClass.cpp
├── Q11_StudentFileHandling.cpp
├── Q12_CopyFileWithoutSpaces.cpp
└── README.md
```

---

## Programs Overview

| File | Topic | Key Concepts |
|---|---|---|
| Q1_SeriesSum.cpp | Series sum: 1 – 1/2² + 1/3³ – … | Math, command-line args, loops |
| Q2_RemoveDuplicates.cpp | Remove duplicates from an array | Arrays, nested loops |
| Q3_AlphabetOccurrences.cpp | Count each alphabet in text | Command-line args, char arrays |
| Q4_StringManipulation.cpp | String ops without built-in functions | Pointers, menu-driven, char arrays |
| Q5_MergeOrderedArrays.cpp | Merge two sorted arrays | Two-pointer algorithm |
| Q6_BinarySearch.cpp | Binary search (recursive + iterative) | Recursion, sorting |
| Q7_GCD.cpp | GCD (recursive + iterative) | Euclidean algorithm |
| Q8_MatrixClass.cpp | Matrix: Sum, Product, Transpose | Classes, exceptions |
| Q9_PersonStudentEmployee.cpp | Person → Student / Employee | Inheritance, virtual functions, polymorphism |
| Q10_TriangleClass.cpp | Triangle with area calculations | Exception handling, overloading |
| Q11_StudentFileHandling.cpp | Student records to/from file | Binary file I/O, fstream |
| Q12_CopyFileWithoutSpaces.cpp | Copy file, remove whitespace | Text file I/O, isspace() |

---

## Requirements

- **Compiler:** g++ (GCC) with C++17 support
- **OS:** Linux / macOS / Windows (with MinGW or WSL)
- **Standard:** C++17

---

## Compilation Instructions

### Compile a single file
```bash
g++ -std=c++17 Q1_SeriesSum.cpp -o Q1_SeriesSum
```

### Compile all files (Linux/macOS – run from CPP_Practicals folder)
```bash
for f in Q*.cpp; do
    name="${f%.cpp}"
    g++ -std=c++17 "$f" -o "$name" && echo "Compiled: $name"
done
```

### Compile all files (Windows CMD)
```cmd
for %f in (Q*.cpp) do g++ -std=c++17 %f -o %~nf.exe
```

---

## Execution Instructions

| Program | Command | Notes |
|---|---|---|
| Q1 | `./Q1_SeriesSum 5` | Or run without args and enter N |
| Q2 | `./Q2_RemoveDuplicates` | Interactive input |
| Q3 | `./Q3_AlphabetOccurrences "Hello World"` | Pass text in quotes |
| Q4 | `./Q4_StringManipulation` | Menu-driven |
| Q5 | `./Q5_MergeOrderedArrays` | Interactive input |
| Q6 | `./Q6_BinarySearch` | Array must be sorted |
| Q7 | `./Q7_GCD` | Enter two numbers |
| Q8 | `./Q8_MatrixClass` | Menu-driven |
| Q9 | `./Q9_PersonStudentEmployee` | No input needed (demo) |
| Q10 | `./Q10_TriangleClass` | Exception demos + interactive |
| Q11 | `./Q11_StudentFileHandling` | Creates students.dat |
| Q12 | `./Q12_CopyFileWithoutSpaces source.txt out.txt` | Auto-creates source.txt if missing |

---

## Key Concepts Covered

### Arrays & Loops
- Q1: Alternating series sum with `pow()`
- Q2: Duplicate detection with nested loops
- Q5: Two-pointer merge algorithm

### Strings (without built-in functions)
- Q3: Command-line text processing, character frequency table
- Q4: Custom `myLength`, `myConcat`, `myCompare`, `myReverse`, `myInsert` using pointers

### Recursion
- Q6: Recursive binary search
- Q7: Recursive GCD (Euclidean algorithm)

### Object-Oriented Programming
- Q8: Matrix class with static methods and runtime exceptions
- Q9: Inheritance chain (Person → Student/Employee), `virtual` functions, runtime polymorphism
- Q10: Overloaded `area()` functions, constructor-level validation

### Exception Handling
- Q8: `throw runtime_error` in Matrix operations, caught in `main()`
- Q10: `throw invalid_argument` for invalid triangle sides

### File Handling
- Q11: Binary file I/O using `write()` and `read()` with `fstream`
- Q12: Text file character-by-character processing with `isspace()`

---

## Tips for Beginners

1. **Compile one file at a time** to learn what each program does.
2. **Read the comments** inside each `.cpp` file — they explain the logic step by step.
3. For Q4 (String Manipulation), try each menu option to understand pointer-based string operations.
4. For Q9, notice how the **same pointer** (`Person* ptr`) calls different `display()` functions depending on what object it points to — this is **runtime polymorphism**.
5. For Q11, the output file `students.dat` is in **binary format** — don't open it in a text editor.
