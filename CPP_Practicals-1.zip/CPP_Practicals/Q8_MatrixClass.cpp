/*
 * Program: Q8_MatrixClass.cpp
 * Purpose: Create a Matrix class with menu-driven operations:
 *          a) Sum (Addition)
 *          b) Product (Multiplication)
 *          c) Transpose
 *          Exceptions are thrown if matrices are incompatible,
 *          and handled in main().
 * Logic:
 *   - For Sum:       Both matrices must have same dimensions.
 *   - For Product:   Columns of matrix A must equal Rows of matrix B.
 *   - For Transpose: Any single matrix (rows become columns).
 *
 * Compile: g++ Q8_MatrixClass.cpp -o Q8_MatrixClass
 * Run:     ./Q8_MatrixClass
 */

#include <iostream>
#include <stdexcept>   // for runtime_error
using namespace std;

// ---- Matrix Class ----
class Matrix {
private:
    int rows, cols;
    int data[10][10];   // Fixed max size of 10x10 for simplicity

public:
    // Constructor
    Matrix(int r, int c) : rows(r), cols(c) {
        // Initialize all elements to 0
        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++)
                data[i][j] = 0;
    }

    // Getter for rows and columns
    int getRows() const { return rows; }
    int getCols() const { return cols; }

    // Input matrix elements from user
    void input() {
        cout << "Enter " << rows << "x" << cols << " matrix elements row by row:" << endl;
        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++) {
                cout << "  [" << i+1 << "][" << j+1 << "]: ";
                cin >> data[i][j];
            }
    }

    // Display the matrix
    void display() const {
        for (int i = 0; i < rows; i++) {
            cout << "  [ ";
            for (int j = 0; j < cols; j++) {
                cout << data[i][j];
                if (j < cols - 1) cout << "\t";
            }
            cout << " ]" << endl;
        }
    }

    // Getter for a specific element
    int get(int i, int j) const { return data[i][j]; }

    // Setter for a specific element
    void set(int i, int j, int val) { data[i][j] = val; }

    // ---- (a) Matrix Addition ----
    // Throws exception if dimensions don't match
    static Matrix add(const Matrix& A, const Matrix& B) {
        if (A.rows != B.rows || A.cols != B.cols) {
            throw runtime_error(
                "Matrix addition failed: dimensions must be equal. "
                "Matrix A is " + to_string(A.rows) + "x" + to_string(A.cols) +
                " but Matrix B is " + to_string(B.rows) + "x" + to_string(B.cols)
            );
        }
        Matrix result(A.rows, A.cols);
        for (int i = 0; i < A.rows; i++)
            for (int j = 0; j < A.cols; j++)
                result.data[i][j] = A.data[i][j] + B.data[i][j];
        return result;
    }

    // ---- (b) Matrix Multiplication ----
    // Throws exception if cols of A != rows of B
    static Matrix multiply(const Matrix& A, const Matrix& B) {
        if (A.cols != B.rows) {
            throw runtime_error(
                "Matrix multiplication failed: columns of A must equal rows of B. "
                "A has " + to_string(A.cols) + " cols but B has " + to_string(B.rows) + " rows."
            );
        }
        Matrix result(A.rows, B.cols);
        for (int i = 0; i < A.rows; i++)
            for (int j = 0; j < B.cols; j++)
                for (int k = 0; k < A.cols; k++)
                    result.data[i][j] += A.data[i][k] * B.data[k][j];
        return result;
    }

    // ---- (c) Transpose ----
    // No exception needed — always valid
    static Matrix transpose(const Matrix& A) {
        Matrix result(A.cols, A.rows);   // Rows and cols are swapped
        for (int i = 0; i < A.rows; i++)
            for (int j = 0; j < A.cols; j++)
                result.data[j][i] = A.data[i][j];
        return result;
    }
};

// ---- Helper: Read a matrix from user ----
Matrix readMatrix(const string& name) {
    int r, c;
    cout << "Enter dimensions of " << name << " (rows cols): ";
    cin >> r >> c;
    Matrix m(r, c);
    m.input();
    return m;
}

// ---- Main Program ----
int main() {
    int choice;

    do {
        cout << "\n===== Matrix Operations Menu =====" << endl;
        cout << "1. Sum (Addition) of two matrices" << endl;
        cout << "2. Product (Multiplication) of two matrices" << endl;
        cout << "3. Transpose of a matrix" << endl;
        cout << "0. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        try {
            // Exceptions thrown inside operations are caught here in main()
            switch (choice) {
                case 1: {
                    cout << "\n-- Matrix Addition --" << endl;
                    Matrix A = readMatrix("Matrix A");
                    Matrix B = readMatrix("Matrix B");
                    Matrix result = Matrix::add(A, B);
                    cout << "\nMatrix A:" << endl; A.display();
                    cout << "Matrix B:" << endl; B.display();
                    cout << "A + B =" << endl; result.display();
                    break;
                }
                case 2: {
                    cout << "\n-- Matrix Multiplication --" << endl;
                    Matrix A = readMatrix("Matrix A");
                    Matrix B = readMatrix("Matrix B");
                    Matrix result = Matrix::multiply(A, B);
                    cout << "\nMatrix A:" << endl; A.display();
                    cout << "Matrix B:" << endl; B.display();
                    cout << "A x B =" << endl; result.display();
                    break;
                }
                case 3: {
                    cout << "\n-- Matrix Transpose --" << endl;
                    Matrix A = readMatrix("Matrix A");
                    Matrix result = Matrix::transpose(A);
                    cout << "\nOriginal Matrix A:" << endl; A.display();
                    cout << "Transpose of A:" << endl; result.display();
                    break;
                }
                case 0:
                    cout << "Exiting. Goodbye!" << endl;
                    break;
                default:
                    cout << "Invalid choice. Try again." << endl;
            }
        } catch (runtime_error& e) {
            // Exception caught in main() as required by the question
            cout << "\n[ERROR] " << e.what() << endl;
        }

    } while (choice != 0);

    return 0;
}

/*
 * Sample Input/Output:
 * -------------------
 * Choice: 1 (Addition)
 * Matrix A (2x2): 1 2 / 3 4
 * Matrix B (2x2): 5 6 / 7 8
 * A + B = [ 6  8 ] / [ 10 12 ]
 *
 * Choice: 1 (Addition with incompatible sizes)
 * Matrix A (2x2), Matrix B (2x3)
 * [ERROR] Matrix addition failed: dimensions must be equal. A is 2x2 but B is 2x3
 *
 * Choice: 2 (Multiplication)
 * A (2x3), B (3x2) -> Result is 2x2
 */
