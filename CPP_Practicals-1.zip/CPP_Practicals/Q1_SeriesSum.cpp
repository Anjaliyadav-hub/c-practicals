/*
 * Program: Q1_SeriesSum.cpp
 * Purpose: Compute the sum of the first N terms of the series:
 *          sum = 1 - 1/2^2 + 1/3^3 - ...
 * Logic:
 *   - Each term = (-1)^(i+1) / i^i  (alternating sign, denominator is i^i)
 *   - N is taken from command-line argument if provided, else prompted
 * Input:  N (number of terms)
 * Output: Sum of the series
 *
 * Compile: g++ Q1_SeriesSum.cpp -o Q1_SeriesSum
 * Run:     ./Q1_SeriesSum 5        (or just ./Q1_SeriesSum and enter N)
 *
 * Sample Output (N=4):
 *   Sum of 4 terms = 1 - 1/4 + 1/27 - 1/256 = 0.787...
 */

#include <iostream>
#include <cmath>       // for pow()
#include <cstdlib>     // for atoi()
using namespace std;

int main(int argc, char* argv[]) {
    int n;

    // Check if N was given as a command-line argument
    if (argc >= 2) {
        n = atoi(argv[1]);   // Convert string argument to integer
        cout << "Using command-line argument: N = " << n << endl;
    } else {
        // Prompt user to enter N
        cout << "Enter the number of terms (N): ";
        cin >> n;
    }

    if (n <= 0) {
        cout << "N must be a positive integer." << endl;
        return 1;
    }

    double sum = 0.0;

    // Loop through each term of the series
    for (int i = 1; i <= n; i++) {
        // Calculate i^i (i raised to the power i)
        double denominator = pow(i, i);

        // Alternating sign: positive for odd i, negative for even i
        double sign = (i % 2 == 1) ? 1.0 : -1.0;

        // Add the current term to the sum
        sum += sign / denominator;
    }

    cout << "Sum of first " << n << " terms = " << sum << endl;

    return 0;
}

/*
 * Sample Input/Output:
 * -------------------
 * Enter the number of terms (N): 4
 * Sum of first 4 terms = 0.787052
 *
 * ./Q1_SeriesSum 5
 * Using command-line argument: N = 5
 * Sum of first 5 terms = 0.787389
 */
