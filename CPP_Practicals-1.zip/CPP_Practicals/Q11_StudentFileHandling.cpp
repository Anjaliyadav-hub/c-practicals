/*
 * Program: Q11_StudentFileHandling.cpp
 * Purpose: Create a Student class with fields:
 *          Roll No., Name, Class, Year, Total Marks
 *          Store 5 Student objects to a binary file, then retrieve and display.
 *
 * File Operations Used:
 *   - ofstream: Open file for writing
 *   - ifstream: Open file for reading
 *   - write():  Write binary data (struct/object) to file
 *   - read():   Read binary data from file
 *
 * Compile: g++ Q11_StudentFileHandling.cpp -o Q11_StudentFileHandling
 * Run:     ./Q11_StudentFileHandling
 */

#include <iostream>
#include <fstream>   // for file I/O (ofstream, ifstream)
#include <cstring>   // for strncpy
using namespace std;

// ---- Student Class ----
class Student {
public:
    int  rollNo;
    char name[50];
    char className[20];
    int  year;
    float totalMarks;

    // Default constructor
    Student() : rollNo(0), year(0), totalMarks(0.0f) {
        name[0] = '\0';
        className[0] = '\0';
    }

    // Parameterized constructor
    Student(int r, const char* n, const char* c, int y, float m)
        : rollNo(r), year(y), totalMarks(m) {
        strncpy(name, n, sizeof(name) - 1);
        name[sizeof(name) - 1] = '\0';
        strncpy(className, c, sizeof(className) - 1);
        className[sizeof(className) - 1] = '\0';
    }

    // Input student details from user
    void input(int index) {
        cout << "\nEnter details for Student " << index << ":" << endl;
        cout << "  Roll No.    : "; cin >> rollNo;
        cin.ignore();
        cout << "  Name        : "; cin.getline(name, 50);
        cout << "  Class       : "; cin.getline(className, 20);
        cout << "  Year        : "; cin >> year;
        cout << "  Total Marks : "; cin >> totalMarks;
        cin.ignore();
    }

    // Display student record
    void display() const {
        cout << "  Roll No.    : " << rollNo     << endl;
        cout << "  Name        : " << name       << endl;
        cout << "  Class       : " << className  << endl;
        cout << "  Year        : " << year       << endl;
        cout << "  Total Marks : " << totalMarks << endl;
    }
};

int main() {
    const int NUM_STUDENTS = 5;
    const string FILENAME = "students.dat";   // Binary file name

    Student students[NUM_STUDENTS];

    // ---- WRITE: Input 5 students and write to file ----
    cout << "===== Enter Student Records =====" << endl;
    for (int i = 0; i < NUM_STUDENTS; i++) {
        students[i].input(i + 1);
    }

    // Open file for writing in binary mode
    ofstream outFile(FILENAME, ios::binary);
    if (!outFile) {
        cout << "Error: Could not open file for writing." << endl;
        return 1;
    }

    // Write each Student object as raw binary data
    for (int i = 0; i < NUM_STUDENTS; i++) {
        outFile.write(reinterpret_cast<char*>(&students[i]), sizeof(Student));
    }
    outFile.close();
    cout << "\n[INFO] " << NUM_STUDENTS << " records written to file: " << FILENAME << endl;

    // ---- READ: Read records back from file and display ----
    cout << "\n===== Reading Records from File =====" << endl;

    // Open file for reading in binary mode
    ifstream inFile(FILENAME, ios::binary);
    if (!inFile) {
        cout << "Error: Could not open file for reading." << endl;
        return 1;
    }

    Student readStudent;
    int count = 0;

    // Read records one by one until end of file
    while (inFile.read(reinterpret_cast<char*>(&readStudent), sizeof(Student))) {
        count++;
        cout << "\n--- Student " << count << " ---" << endl;
        readStudent.display();
    }
    inFile.close();

    cout << "\n[INFO] Total records retrieved: " << count << endl;

    return 0;
}

/*
 * Sample Input/Output:
 * -------------------
 * ===== Enter Student Records =====
 * Enter details for Student 1:
 *   Roll No.    : 101
 *   Name        : Alice
 *   Class       : BSc CS
 *   Year        : 2
 *   Total Marks : 450
 * ...
 *
 * [INFO] 5 records written to file: students.dat
 *
 * ===== Reading Records from File =====
 * --- Student 1 ---
 *   Roll No.    : 101
 *   Name        : Alice
 *   Class       : BSc CS
 *   Year        : 2
 *   Total Marks : 450
 * ...
 * [INFO] Total records retrieved: 5
 */
