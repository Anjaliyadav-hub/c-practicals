/*
 * Program: Q2_RemoveDuplicates.cpp
 * Purpose: Remove duplicate elements from an array
 * Logic:
 *   - For each element, check if it has appeared before.
 *   - If not, keep it in the result array.
 * Input:  Array size and elements
 * Output: Array without duplicate values
 *
 * Compile: g++ Q2_RemoveDuplicates.cpp -o Q2_RemoveDuplicates
 * Run:     ./Q2_RemoveDuplicates
 *
 * Sample Output:
 *   Original: 1 2 3 2 4 3 5
 *   After removing duplicates: 1 2 3 4 5
 */

#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter the size of the array: ";
    cin >> n;

    int arr[n];
    cout << "Enter " << n << " elements: ";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    // Print original array
    cout << "\nOriginal array: ";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;

    // Array to store unique elements
    int unique[n];
    int uniqueCount = 0;

    // Check each element if it's a duplicate
    for (int i = 0; i < n; i++) {
        bool isDuplicate = false;

        // Check if arr[i] already exists in the unique array
        for (int j = 0; j < uniqueCount; j++) {
            if (arr[i] == unique[j]) {
                isDuplicate = true;
                break;
            }
        }

        // If not a duplicate, add to unique array
        if (!isDuplicate) {
            unique[uniqueCount] = arr[i];
            uniqueCount++;
        }
    }

    // Print result
    cout << "After removing duplicates: ";
    for (int i = 0; i < uniqueCount; i++) {
        cout << unique[i] << " ";
    }
    cout << endl;
    cout << "Total unique elements: " << uniqueCount << endl;

    return 0;
}

/*
 * Sample Input/Output:
 * -------------------
 * Enter the size of the array: 7
 * Enter 7 elements: 1 2 3 2 4 3 5
 *
 * Original array: 1 2 3 2 4 3 5
 * After removing duplicates: 1 2 3 4 5
 * Total unique elements: 5
 */
