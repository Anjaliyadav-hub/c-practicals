/*
 * Program: Q7_GCD.cpp
 * Purpose: Calculate the GCD (Greatest Common Divisor) of two numbers
 *          (i) With recursion
 *          (ii) Without recursion (iterative)
 * Logic:
 *   - Uses Euclidean Algorithm: GCD(a, b) = GCD(b, a % b)
 *   - Base case: GCD(a, 0) = a
 * Input:  Two positive integers
 * Output: GCD of the two numbers
 *
 * Compile: g++ Q7_GCD.cpp -o Q7_GCD
 * Run:     ./Q7_GCD
 */

#include <iostream>
using namespace std;

// ---- (i) GCD WITH Recursion ----
// Euclidean algorithm: GCD(a, b) = GCD(b, a % b)
int gcdRecursive(int a, int b) {
    if (b == 0) return a;       // Base case: GCD(a, 0) = a
    return gcdRecursive(b, a % b);  // Recursive call with remainder
}

// ---- (ii) GCD WITHOUT Recursion (Iterative) ----
int gcdIterative(int a, int b) {
    while (b != 0) {
        int remainder = a % b;
        a = b;
        b = remainder;
    }
    return a;   // When b becomes 0, a holds the GCD
}

int main() {
    int num1, num2;

    cout << "Enter two positive integers:" << endl;
    cout << "Number 1: ";
    cin >> num1;
    cout << "Number 2: ";
    cin >> num2;

    if (num1 <= 0 || num2 <= 0) {
        cout << "Please enter positive integers only." << endl;
        return 1;
    }

    // Display GCD using both methods
    cout << "\n(i)  GCD using Recursion  : " << gcdRecursive(num1, num2)  << endl;
    cout << "(ii) GCD using Iteration  : " << gcdIterative(num1, num2)  << endl;

    return 0;
}

/*
 * Sample Input/Output:
 * -------------------
 * Enter two positive integers:
 * Number 1: 48
 * Number 2: 18
 *
 * (i)  GCD using Recursion  : 6
 * (ii) GCD using Iteration  : 6
 *
 * Another example:
 * Number 1: 100
 * Number 2: 75
 * (i)  GCD using Recursion  : 25
 * (ii) GCD using Iteration  : 25
 */
