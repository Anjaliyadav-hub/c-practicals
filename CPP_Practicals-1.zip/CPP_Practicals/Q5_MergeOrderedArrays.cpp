/*
 * Program: Q5_MergeOrderedArrays.cpp
 * Purpose: Merge two sorted (ordered) arrays into a single sorted array.
 * Logic:
 *   - Use the classic two-pointer merge technique.
 *   - Compare elements from both arrays and always pick the smaller one.
 *   - Append remaining elements from whichever array isn't exhausted.
 * Input:  Two sorted arrays with their sizes
 * Output: A single merged sorted array
 *
 * Compile: g++ Q5_MergeOrderedArrays.cpp -o Q5_MergeOrderedArrays
 * Run:     ./Q5_MergeOrderedArrays
 *
 * Sample Output:
 *   Merged array: 1 2 3 4 5 6 7 8
 */

#include <iostream>
using namespace std;

// Function to merge two sorted arrays into result[]
void mergeSortedArrays(int arr1[], int n1, int arr2[], int n2, int result[]) {
    int i = 0;   // Pointer for arr1
    int j = 0;   // Pointer for arr2
    int k = 0;   // Pointer for result

    // Compare elements and add the smaller one to result
    while (i < n1 && j < n2) {
        if (arr1[i] <= arr2[j]) {
            result[k] = arr1[i];
            i++;
        } else {
            result[k] = arr2[j];
            j++;
        }
        k++;
    }

    // If arr1 still has remaining elements, add them
    while (i < n1) {
        result[k] = arr1[i];
        i++;
        k++;
    }

    // If arr2 still has remaining elements, add them
    while (j < n2) {
        result[k] = arr2[j];
        j++;
        k++;
    }
}

// Utility function to print an array
void printArray(int arr[], int n) {
    for (int i = 0; i < n; i++) {
        cout << arr[i];
        if (i < n - 1) cout << " ";
    }
    cout << endl;
}

int main() {
    int n1, n2;

    cout << "Enter size of first sorted array: ";
    cin >> n1;
    int arr1[n1];
    cout << "Enter " << n1 << " elements in sorted (ascending) order: ";
    for (int i = 0; i < n1; i++) cin >> arr1[i];

    cout << "Enter size of second sorted array: ";
    cin >> n2;
    int arr2[n2];
    cout << "Enter " << n2 << " elements in sorted (ascending) order: ";
    for (int i = 0; i < n2; i++) cin >> arr2[i];

    // Result array has combined size
    int merged[n1 + n2];

    // Merge the two arrays
    mergeSortedArrays(arr1, n1, arr2, n2, merged);

    // Display all arrays
    cout << "\nFirst array:  ";  printArray(arr1, n1);
    cout << "Second array: ";    printArray(arr2, n2);
    cout << "Merged array: ";    printArray(merged, n1 + n2);

    return 0;
}

/*
 * Sample Input/Output:
 * -------------------
 * Enter size of first sorted array: 4
 * Enter 4 elements in sorted order: 1 3 5 7
 * Enter size of second sorted array: 4
 * Enter 4 elements in sorted order: 2 4 6 8
 *
 * First array:  1 3 5 7
 * Second array: 2 4 6 8
 * Merged array: 1 2 3 4 5 6 7 8
 */
