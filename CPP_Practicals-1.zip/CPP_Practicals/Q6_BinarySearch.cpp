/*
 * Program: Q6_BinarySearch.cpp
 * Purpose: Search for an element in a sorted array using Binary Search
 *          (i) With recursion
 *          (ii) Without recursion (iterative)
 * Logic:
 *   - Binary Search works on SORTED arrays.
 *   - It repeatedly divides the search range in half.
 *   - Compare target with middle element; search left or right half accordingly.
 * Input:  N numbers (sorted), and a target element to search
 * Output: Index of the element if found, or "not found" message
 *
 * Compile: g++ Q6_BinarySearch.cpp -o Q6_BinarySearch
 * Run:     ./Q6_BinarySearch
 */

#include <iostream>
using namespace std;

// ---- (i) Binary Search WITH Recursion ----
// Returns index of target in arr[low..high], or -1 if not found
int binarySearchRecursive(int arr[], int low, int high, int target) {
    // Base case: search range is invalid — element not found
    if (low > high) return -1;

    int mid = low + (high - low) / 2;   // Calculate middle index (avoids overflow)

    if (arr[mid] == target) {
        return mid;   // Found at index mid
    } else if (arr[mid] < target) {
        // Target is in the RIGHT half — search right
        return binarySearchRecursive(arr, mid + 1, high, target);
    } else {
        // Target is in the LEFT half — search left
        return binarySearchRecursive(arr, low, mid - 1, target);
    }
}

// ---- (ii) Binary Search WITHOUT Recursion (Iterative) ----
// Returns index of target in arr[], or -1 if not found
int binarySearchIterative(int arr[], int n, int target) {
    int low  = 0;
    int high = n - 1;

    while (low <= high) {
        int mid = low + (high - low) / 2;   // Midpoint

        if (arr[mid] == target) {
            return mid;   // Found
        } else if (arr[mid] < target) {
            low = mid + 1;    // Search right half
        } else {
            high = mid - 1;   // Search left half
        }
    }

    return -1;   // Not found
}

int main() {
    int n;
    cout << "Enter number of elements (N): ";
    cin >> n;

    int arr[n];
    cout << "Enter " << n << " elements in SORTED (ascending) order: ";
    for (int i = 0; i < n; i++) cin >> arr[i];

    int target;
    cout << "Enter the element to search: ";
    cin >> target;

    // --- Method (i): Recursive ---
    int resultRec = binarySearchRecursive(arr, 0, n - 1, target);
    cout << "\n(i) Recursive Binary Search: ";
    if (resultRec != -1)
        cout << "Element " << target << " found at index " << resultRec << " (1-based: " << resultRec + 1 << ")" << endl;
    else
        cout << "Element " << target << " NOT FOUND in the array." << endl;

    // --- Method (ii): Iterative ---
    int resultIter = binarySearchIterative(arr, n, target);
    cout << "(ii) Iterative Binary Search: ";
    if (resultIter != -1)
        cout << "Element " << target << " found at index " << resultIter << " (1-based: " << resultIter + 1 << ")" << endl;
    else
        cout << "Element " << target << " NOT FOUND in the array." << endl;

    return 0;
}

/*
 * Sample Input/Output:
 * -------------------
 * Enter number of elements (N): 7
 * Enter 7 elements in sorted order: 10 20 30 40 50 60 70
 * Enter the element to search: 40
 *
 * (i)  Recursive Binary Search: Element 40 found at index 3 (1-based: 4)
 * (ii) Iterative Binary Search: Element 40 found at index 3 (1-based: 4)
 *
 * Enter the element to search: 25
 * (i)  Recursive Binary Search: Element 25 NOT FOUND in the array.
 * (ii) Iterative Binary Search: Element 25 NOT FOUND in the array.
 */
